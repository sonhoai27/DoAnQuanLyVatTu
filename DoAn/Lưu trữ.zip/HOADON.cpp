#include "HOADON.h"

int HOADON::AutoNumber = 0;

HOADON::HOADON(DS_VATTU & KhoaChua)
{
	AutoNumber++;
	SoHD = AutoNumber;
	cout << "\nNgay Lap Hoa Don: ";
	cin >> NgLapHD;
	cout << "\nLoai Hoa Don: ";
	do {
		fflush(stdin);
		char c;
		c = getch();
		if (c == 'N' || c == 'n' || c == 'X' || c == 'x') {
			Loai = c;
			cout << Loai;
			break;
		}
	} while (true);
	if (Loai == 'N' || Loai == 'n') {
		PhieuNhap();
	}
	else {
		if (Loai == 'X' || Loai == 'x') {
			PhieuXuat();
		}
	}
}

void HOADON::Xuat()
{
}

void HOADON::PhieuNhap()
{
}

void HOADON::PhieuXuat()
{
}

HOADON::HOADON()
{
}


HOADON::~HOADON()
{
}
