#include "VATTU.h"
#include "DS_VATTU.h"

int DS_VATTU::Full() {
	if (n == MaxSize) {
		return 0; //danh sach day
	}
	else {
		return 1; //danh sach chua day
	}
}

void DS_VATTU::Them() {
	if (n == 0) {
		n = 0;
		if (n < MaxSize) {
			node[n].Nhap();
			n++;
		}
		else {
			cout << "\nDanh Sach Day";
		}
	}
}

void DS_VATTU::XoaVT(string mavt) {
	for (int i = 0; i < n; i++) {
		if (node[i].getMAVT() != mavt) {
			cout << "\nKhong co ma vat tu " << mavt;
		}
		else {
			for (int j = i; j < n - 1; j++) {
				node[j] = node[j + 1];
			}
			n--;
		}
	}
}

void DS_VATTU::SuaVT(string mavt) {
	int LuaChon;
	string tenvt, mavt;
	for (int i = 0; i < n; i++) {
		if (node[i].getMAVT() == mavt) {
			while (true) {
				cout << "\n1. Sua MVT";
				cout << "\n2. Sua TENVT";
				cout << "\n0. Thoat";
				cout << "\nNhap vao lua chon: "; cin >> LuaChon;
				if (LuaChon == 0) {
					break;
				}
				else {
					switch (LuaChon) {
					case 1:
						cout << "\nNhap vao MVT moi: "; fflush(stdin); getline(cin, mavt); node[i].setMAVT(mavt); break;
					case 2:
						cout << "\nNhap vao TENVT moi: "; fflush(stdin); getline(cin, tenvt); node[i].setTENVT(tenvt); break;
					}
				}
			}
		}
		else {
			cout << "\nKo co Vat tu do";
		}
	}
}

int DS_VATTU::SoLuongVT()
{
	return n;
}

void DS_VATTU::Xuat() {
	for (int i = 0; i < n; i++) {
		node[i].Xuat();
		cout << "\n";
	}
}
DS_VATTU::DS_VATTU()
{

}


DS_VATTU::~DS_VATTU()
{

}
