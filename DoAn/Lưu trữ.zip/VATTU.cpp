#include "VATTU.h"

void VATTU::Nhap() {
	cout << "\nMa Vat Tu: ";
	fflush(stdin);
	getline(cin, MaVT);
	cout << "\nTen Vat Tu: ";
	fflush(stdin);
	getline(cin, TenVT);
	cout << "\nDon Vi Tinh: ";
	fflush(stdin);
	getline(cin, DVT);
	cout << "\nSo Luong Ton: ";
	cin >> SoLuongTon;

}

void VATTU::Xuat() {
	cout << "\nMa Vat TU: " << MaVT;
	cout << "\nTen Vat Tu: " << TenVT;
	cout << "\nDon Vi Tinh: " << DVT;
	cout << "\nSo Luong Ton: " << SoLuongTon;
}

//get
string VATTU::getMAVT() {
	return MaVT;
}

string VATTU::getTENVT() {
	return TenVT;
}

string VATTU::getDVT() {
	return DVT;
}

int VATTU::getSLT() {
	return SoLuongTon;
}

//set
void VATTU::setMAVT(string x) {
	MaVT = x;
}

void VATTU::setTENVT(string x) {
	TenVT = x;
}

void VATTU::setSLT(int x) {
	SoLuongTon = x;
}

void VATTU::setDVT(string x) {
	DVT = x;
}

VATTU::VATTU()
{
}


VATTU::~VATTU()
{
}
