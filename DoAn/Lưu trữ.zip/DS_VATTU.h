#pragma once
#include "VATTU.h"
class DS_VATTU
{
private:
	int n;//soluong
	VATTU node[MaxSize];
public:
	int Full();
	void Them();
	void Xuat();
	void XoaVT(string mavt);
	void SuaVT(string mavt);
	int SoLuongVT();
	DS_VATTU();
	~DS_VATTU();
};

