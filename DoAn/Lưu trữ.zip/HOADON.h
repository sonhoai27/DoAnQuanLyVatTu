#pragma once
#include "VATTU.h"
#include "DS_VATTU.h"
class HOADON
{
private:
	int SoHD, NgLapHD;
	char Loai;
	DS_VATTU DsCon;
public:
	int static AutoNumber;
	HOADON(DS_VATTU &KhoaChua); //truyen vao ds kho
	void Xuat(); //xuat to hoa don ra
	void PhieuNhap();
	void PhieuXuat();
	HOADON();
	~HOADON();
};

